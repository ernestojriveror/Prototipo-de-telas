# Rotina Diária: do tema ao protótipo de telas

Prática: Pontos 01 e 02 (tema, problema do MVP, persona, histórias de usuário, hipóteses e priorização)

## Ponto 01 – Tema e problema do MVP

**Tema escolhido:** organizador de rotina diária (acordar, tomar café da manhã, ir à academia, trabalhar, almoçar, etc.).

**Diferença em relação a uma lista de tarefas comum:** o app não é uma lista de pendências soltas. É uma rotina com horários e ordem, que se repete todos os dias e mostra sempre qual é a próxima atividade.

**Definição do problema:**

Pessoas com uma rotina diária cheia têm dificuldade para lembrar e cumprir suas atividades na ordem e no horário certos, porque dependem da memória ou de anotações soltas. Isso gera desorganização, atrasos e a sensação de que o dia não rende.

**Objetivo do MVP:** permitir que a pessoa monte sua rotina do dia, veja o que vem agora e a seguir, e marque o que já foi feito, em poucos toques.

## Ponto 02 – Definição com IA

### Persona

**Nome:** Lucas Almeida
**Idade:** 24 anos
**Cidade:** Chapecó, SC
**Ocupação:** estudante de Sistemas de Informação e estagiário de desenvolvimento, meio período.

**Rotina:** acorda às 6h30, vai à academia às 7h, trabalha das 9h às 13h, almoça, assiste às aulas à noite e estuda em casa.

**Frustrações:**
- Esquece atividades quando o dia muda um pouco.
- Usa notas soltas no celular e perde o fio da organização.
- Perde tempo decidindo o que fazer a seguir.
- Começa bem a semana, mas abandona o planejamento por falta de constância.

**Objetivos:**
- Ter uma visão clara do dia em uma única tela.
- Cumprir a rotina com mais constância.
- Ver o que já fez para sentir progresso.

**Frase que o define:** "Eu sei o que preciso fazer, mas o dia me escapa."

### Histórias de usuário

1. Como usuário, quero cadastrar uma atividade com nome e horário, para montar minha rotina do dia.
2. Como usuário, quero ver minhas atividades em ordem cronológica, para saber o que vem a seguir.
3. Como usuário, quero marcar uma atividade como concluída, para acompanhar meu progresso.
4. Como usuário, quero editar ou excluir uma atividade, para ajustar minha rotina quando ela mudar.
5. Como usuário, quero ver quantas atividades concluí no dia, para me sentir motivado.
6. Como usuário, quero escolher em quais dias da semana uma atividade se repete, para não recadastrar tudo todo dia.
7. Como usuário, quero receber lembretes no horário das atividades, para não esquecer.
8. Como usuário, quero ver o histórico dos dias anteriores, para avaliar minha constância.

### Revisão de hipóteses

| # | Hipótese | Como validar |
|---|----------|--------------|
| H1 | As pessoas esquecem atividades porque dependem da memória ou de notas soltas. | Entrevistar 3 a 5 colegas sobre como organizam o dia hoje. |
| H2 | Ver o dia em ordem cronológica em uma única tela ajuda a cumprir mais atividades. | Testar o protótipo com 3 pessoas e observar se identificam a próxima atividade em menos de 5 segundos. |
| H3 | Marcar atividades como concluídas aumenta a motivação. | Perguntar aos testadores se o progresso do dia os incentiva. |
| H4 | O usuário prefere cadastrar a rotina uma vez e vê-la repetida a cada dia. | Observar se os testadores esperam que as atividades se repitam. |
| H5 | Lembretes são essenciais para o uso diário. | Perguntar se usariam o app sem lembretes. Se sim, os lembretes podem ficar para depois. |

**Riscos das hipóteses:** todas partem de poucas conversas e da experiência do próprio autor. Antes de investir em funções extras, vale validá-las com pelo menos 3 pessoas reais.

### Priorização (MoSCoW)

**Must have (entra no MVP):**
- Cadastrar atividade com nome e horário.
- Listar as atividades do dia em ordem cronológica.
- Marcar atividade como concluída.
- Editar e excluir atividade.
- Indicador simples de progresso do dia (ex.: 3 de 6 concluídas).

**Should have (importante, mas pode esperar a versão 2):**
- Repetição por dias da semana.
- Destaque da próxima atividade.

**Could have (desejável):**
- Lembretes e notificações.
- Histórico dos dias anteriores.
- Categorias com cores e ícones.

**Won't have (fora do escopo por enquanto):**
- Contas de usuário e sincronização na nuvem.
- Compartilhamento de rotina com outras pessoas.
- Integração com calendário externo.
- Gamificação avançada (pontos, medalhas, rankings).

**Telas principais derivadas do escopo (para o Ponto 03):**
1. Rotina de hoje (tela inicial)
2. Nova atividade / editar atividade
3. Progresso do dia
