# Rotina Diária – Pacote do projeto

Conteúdo:
- documentacao-pontos-01-02.md: tema, problema do MVP, persona, histórias de usuário, hipóteses e priorização MoSCoW.
- prototipo-telas.html: protótipo funcional com as 3 telas principais (Hoje, Nova/editar atividade e Progresso). Abra no navegador com um clique duplo.

Funções do protótipo:
- Cadastrar, editar e excluir atividades (nome, horário e dias da semana).
- Lista do dia em ordem de horário, com destaque da próxima atividade.
- Marcar atividades como concluídas e acompanhar o progresso do dia e dos últimos 7 dias.
- Os dados ficam salvos no navegador (localStorage).
